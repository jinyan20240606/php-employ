<?php

namespace app\common\model;

use think\Model;

class Auth extends Model
{

}
