<?php

namespace app\common\model;

use think\Model;

class Attribute extends Model
{
    //
}
