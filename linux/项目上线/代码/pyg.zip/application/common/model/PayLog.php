<?php

namespace app\common\model;

use think\Model;

class PayLog extends Model
{
    //
}
