<?php

namespace app\admin\model;

use think\Model;

class PayLog extends Model
{
    //
}
