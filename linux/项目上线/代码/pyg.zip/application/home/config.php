<?php
//配置文件
return [
    'template' => [
        'layout_on' => true,
        'layout_name' => 'layout'
    ]
];