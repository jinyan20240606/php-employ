<?php

namespace app\adminapi\logic;
class AuthLogic
{
    //权限检测
    public static function check()
    {
        //判断是否是特殊页面（比如首页）
        $controller = request()->controller();
        $action = request()->action();
        if ($controller == 'Index' && $action == 'Index') {
            //不需要检测
            return true;
        }
        //获取到管理员列表的角色id
        $user_id = input('user_id');
        $info = \app\common\model\Admin::find($user_id);
        $role_id = $info['role_id'];
        //判断是否是超级管理员（超级管理员不需要检测）
        if ($role_id == 1) {
            //不需要检测（有权限访问）
            return true;
        }
        //查询当前管理员所拥有的的权限ids（从角色表查询对应role_auth_ids）
        $role = \app\common\model\Role::find($role_id);
        //取出权限ids分割为数组
        $role_auth_ids = explode(',', $role['role_auth_ids']);
        //根据当前访问的控制器、方法查询到的具体的权限id
        $auth = \app\common\model\Auth::where('auth_c', $controller)->where('auth_a', $action)->find();
        $auth_id=$auth['id'];
        //判断当前权限id是否在role_auth_ids范围中
        if(in_array($auth_id,$role_auth_ids)){
            //有权限
            return true;
        }
        //没有访问权限
        return false;
    }
}
