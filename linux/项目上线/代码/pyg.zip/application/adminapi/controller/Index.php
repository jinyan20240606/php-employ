<?php

namespace app\adminapi\controller;

class Index extends BaseApi
{
    public function index()
    {

//        $goods=\think\Db::table('pyg_goods')->find();
//        $this->ok(['action'=>'index']);die;
        $token = \tools\jwt\Token::getToken(200);
        dump($token);
        //解析token 得到用户id
        $user_id = \tools\jwt\Token::getUserId($token);
        dump($user_id);die;

        //        return 4567;
    }
}
