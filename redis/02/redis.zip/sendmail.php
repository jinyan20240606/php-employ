<?php
// php脚本永不过期
set_time_limit(0);
// php发送邮件，可以 phpmailer
// 队列key
$key = 'sendmallist';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require __DIR__ . '/vendor/autoload.php';
$redis = include __DIR__ . '/conn.php';


// 读一下队列是否有记录
$bool = $redis->exists($key);
if(!$bool) return;

while (true){
    // 列表中有数据
    if($redis->lLen($key) > 0){
        $toMail = $redis->rPop($key);
        sendmail($toMail);
    }
    sleep(2);
}




function sendmail(string $tomail){
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->SMTPDebug = 0;                                       // Enable verbose debug output
        $mail->isSMTP();                                            // Set mailer to use SMTP
        $mail->Host = 'smtp.qq.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                                   // Enable SMTP authentication
        $mail->Username = '1658996694@qq.com';                     // SMTP username
        $mail->Password = 'xqgvwyxqpytjcgag';                               // SMTP password
        $mail->SMTPSecure = 'ssl';                                  // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 465;                                    // TCP port to connect to

        //Recipients
        $mail->setFrom('1658996694@qq.com', 'zhangsan');
        $mail->addAddress($tomail, 'lisi');     // Add a recipient

        // Content
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->Subject = '登录提示';
        $mail->Body = '<h3>小伙登录成功了</h3>';
        $mail->send();
        echo "Send ok \n";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
