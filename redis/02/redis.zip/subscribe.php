<?php
// php脚本永不超时
set_time_limit(0);
// 订阅频道
// 实例化redis对象
$redis = new Redis();

// 连接redis  5秒超时
$redis->connect('127.0.0.1', 6379, 5);
// 认证
$redis->auth('admin123');

// 订阅  mail 发邮件 list  1&mail
$redis->subscribe(['php'], function ($redis, $channel, $msg) {
    echo $msg . "\n";
    // 发起修改数据库
    // websocket=>swoole 发起ws
    // 消息队列
});